package com.huawei.server.mos.web.application.utils;
/*
 * 文 件 名:  HttpClientUtils.java
 * 版    权:  Huawei Technologies Co., Ltd. Copyright YYYY-YYYY,  All rights reserved
 * 描    述:  <描述>
 * 修 改 人:  万 柯
 * 修改时间:  16:30 2019/1/15
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */

import java.io.*;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.huawei.server.mos.utils.DateUtils;
import com.huawei.server.mos.utils.StringUtils;
import com.huawei.server.mos.utils.log.LoggerManager;
import com.huawei.server.mos.web.application.controller.vo.UploadCoverPictureVo;
import com.huawei.server.mos.web.application.model.User;


/**
 * httpClient 工具类 <功能详细描述>
 *
 * @author 万 柯
 * @version [版本号, 16:30 2019/1/15]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class HttpClientUtils
{
    private static final Logger LOGGER = LoggerManager.getInterfaceLogger();

    private static PoolingHttpClientConnectionManager cm = null;

    /**
     * 初始化httpclient 连接池
     */
    static
    {
        LayeredConnectionSocketFactory sslsf = null;
        try {
            sslsf = new SSLConnectionSocketFactory(SSLContext.getDefault());
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error(e.getMessage());
        }
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create()
            .register("https", sslsf)
            .register("http", new PlainConnectionSocketFactory())
            .build();
        cm = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        cm.setMaxTotal(200);
        cm.setDefaultMaxPerRoute(20);
    }

    /**
     * 获取httpclient客户端对象
     *
     * @param timeout 超时时间
     * @return Http客户端对象
     */
    private static CloseableHttpClient getHttpClient(Integer timeout)
    {
        RequestConfig requestConfig = RequestConfig.custom().
        // 设置连接超时时间
            setConnectionRequestTimeout(timeout).
            // 设置请求超时时间
            setConnectTimeout(timeout).
            // 设置响应超时时间
            setSocketTimeout(timeout).build();
        int time = 3;
        // 超时重试，服务器丢失连接重试
        HttpRequestRetryHandler retry = new HttpRequestRetryHandler()
        {
            @Override
            public boolean retryRequest(IOException e, int i, HttpContext httpContext)
            {
                // 超过3次不在重试
                if (i >= time) {
                    return false;
                }
                // 如果服务器丢失连接 或者 超时就重试
                if (e instanceof NoHttpResponseException || e instanceof InterruptedIOException) {
                    return true;
                }
                return false;
            }
        };
        return HttpClients.custom()
            .setDefaultRequestConfig(requestConfig)
            .setRetryHandler(retry)
            .setConnectionManager(cm)
            .build();
    }

    /**
     * GET请求
     *
     * @param url 请求地址
     * @param timeOut 超时时间
     * @return msg
     */
    public static String httpGet(String url, Integer timeOut, Map<String, String> param, Map<String, String> header)
    {
        String msg = "";
        // 获取客户端连接对象
        CloseableHttpClient httpClient = getHttpClient(timeOut);
        List<NameValuePair> list = new LinkedList<>();
        for (Map.Entry<String, String> entry : param.entrySet())
        {
            BasicNameValuePair parameter = new BasicNameValuePair(entry.getKey(), entry.getValue());
            list.add(parameter);
        }
        CloseableHttpResponse response = null;
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            uriBuilder.setParameters(list);
            HttpGet httpGet = new HttpGet(uriBuilder.build());
            for (Map.Entry<String, String> entry : header.entrySet())
            {
                httpGet.addHeader(entry.getKey(), entry.getValue());
            }
            // 执行请求
            response = httpClient.execute(httpGet);
            // 获取响应实体
            HttpEntity entity = response.getEntity();
            // 获取响应信息
            msg = EntityUtils.toString(entity, "UTF-8");
        } catch (Exception e) {
            LOGGER.error("请求出错: {}", url);
        } finally {
            if (null != response) {
                try {
                    EntityUtils.consume(response.getEntity());
                    response.close();
                } catch (IOException e) {
                    LOGGER.error("连接释放出错:{}", e.getLocalizedMessage());
                }
            }
        }
        return msg;
    }

    public static String httpPost(String url, Integer timeout, String param, Map<String, String> header)
    {
        String msg = "";
        // 获取客户端连接对象
        CloseableHttpClient httpClient = getHttpClient(timeout);
        HttpPost httpPost = new HttpPost(url);
        CloseableHttpResponse response = null;
        try {
            StringEntity entityParam = new StringEntity(param);
            httpPost.setEntity(entityParam);
            for (Map.Entry<String, String> entry : header.entrySet()) {
                httpPost.addHeader(entry.getKey(), entry.getValue());
            }
            // 执行请求
            response = httpClient.execute(httpPost);
            // 获得响应的实体对象
            HttpEntity entity = response.getEntity();
            msg = EntityUtils.toString(entity, "UTF-8");
        } catch (Exception e) {
            LOGGER.error("请求出错:{}", e.getLocalizedMessage());
        }
        return msg;
    }
    
    public static String httpPostFile(String url, Integer timeout, InputStream in, Map<String, String> header,
        String fileName)
    {
        String msg = "";
        CloseableHttpClient httpClient = getHttpClient(timeout);
        HttpPost httpPost = new HttpPost(url);
        CloseableHttpResponse response;
        
        try
        {
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            // 第一个参数为 相当于 Form表单提交的file框的name值 第二个参数就是我们要发送的InputStream对象了
            // 第三个参数是文件名
            builder.addBinaryBody("file", in, ContentType.create("multipart/form-data"), fileName);
            
            User user = SessionHolder.getUser();
            StringBody CpId = new StringBody(user.getUid(), ContentType.MULTIPART_FORM_DATA);
            builder.addPart("cpId", CpId);
            String transactionId = DateUtils.formatDate(DateUtils.getNowUtcTimeDate(), "yyyyMMddHHmmss")
                + StringUtils.getRandomNumberString(6);
            StringBody transaction = new StringBody(transactionId, ContentType.MULTIPART_FORM_DATA);
            builder.addPart("transactionId", transaction);
            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);

            // 执行请求
            response = httpClient.execute(httpPost);
            // 获得响应的实体对象
            entity = response.getEntity();
            msg = EntityUtils.toString(entity, "UTF-8");
        }
        catch (Exception e)
        {
            LOGGER.error("请求出错:{}", e.getLocalizedMessage());
        }
        return msg;
    }

    public static Map<String, String> getHeader()
    {
        Map<String, String> header = new HashMap();
        header.put("Content-Type", "application/x-www-form-urlencoded");
        return header;
    }

    public static Map<String, String> getHeaders()
    {
        Map<String, String> header = new HashMap();
        header.put("Content-Type", "multipart/form-data");
        return header;
    }
    
    private static String formatFormData(User user, Object param) {
        Map<String,String> paramMap = new HashMap<>();
        if (param != null){
            Field[] fields = param.getClass().getDeclaredFields();
            for (Field field : fields){
                field.setAccessible(true);
                try {
                    paramMap.put(field.getName(),String.valueOf(field.get(param)));
                } catch (IllegalAccessException e) {
                    LOGGER.warn("[HttpRequest]Request field [{}] parse error : {}",field.getName(),e.getMessage());
                }
            }
        }
        if (user != null){
            paramMap.put("cpId", user.getUid());
        }
        paramMap.put("transactionId", DateUtils.formatDate(DateUtils.getNowUtcTimeDate(),"yyyyMMddHHmmss")
                + StringUtils.getRandomNumberString(6));
        StringBuilder params = new StringBuilder();
        paramMap.forEach((key,value) ->{
            if (!StringUtils.isBlank(value)){
                try {
                    params.append(key).append("=").append(URLEncoder.encode(value, Charset.forName("UTF-8").toString())).append("&");
                } catch (UnsupportedEncodingException e) {
                    LOGGER.warn("Request parameter [{}] parse error , encode to http formate with utf-8 error : {}",key,e.getMessage());
                }
            }
        });
        LOGGER.info("[HttpRequest] 请求参数: {}", params.toString());
        return params.toString();
    }

    public static Object processHttpRequest(String serverUrl, Object vo) {
        User user = SessionHolder.getUser();
        LOGGER.info("[HttpRequest] 请求地址:{}", serverUrl);
        String result = httpPost(serverUrl, 30000, formatFormData(user, vo), getHeader());
        LOGGER.info("[HttpRequest]Client request result : {}", result);
        return result;
    }
    
    public static Object processHttpFileRequest(String serverUrl, UploadCoverPictureVo vo)
    {
        LOGGER.info("[HttpRequest] 请求地址:{}", serverUrl);
        
        InputStream in = null;
        String fileName = null;
        try
        {
            MultipartFile file = vo.getFile();
            in = file.getInputStream();
            fileName = file.getOriginalFilename();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
        String result = httpPostFile(serverUrl, 3000, in, getHeader(), fileName);
        LOGGER.info("[HttpRequest]Client request result : {}", result);
        return result;
    }
    
    public static Object processHttpJsonRequest(String serverUrl, Object vo)
    {
        User user = SessionHolder.getUser();
        LOGGER.info("[HttpRequest] 请求地址:{}", serverUrl);
        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
        String result = httpPost(serverUrl, 3000, formatFormData(user, vo), header);
        LOGGER.info("[HttpRequest]Client request result : {}", result);
        return result;
    }
}
